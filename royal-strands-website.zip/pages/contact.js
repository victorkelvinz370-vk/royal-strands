import { Button } from '../components/ui/button'

export default function Contact() {
  return (
    <section className="py-16 text-center px-4">
      <h1 className="text-3xl font-bold text-pink-600 mb-3">Contact & Booking</h1>
      <p className="text-gray-700 mb-4">Phone: <a href="tel:+447946572576" className="text-pink-700">+44 7946 572576</a></p>
      <p className="text-gray-700 mb-4">Email: <a href="mailto:strandsroyal@gmail.com" className="text-pink-700">strandsroyal@gmail.com</a></p>
      <div className="flex items-center justify-center gap-4">
        <a href="https://wa.me/447946572576"><Button className="px-6 py-3 bg-rose-400 text-white">WhatsApp Michelle</Button></a>
        <a href="tel:+447946572576"><Button className="px-6 py-3 bg-pink-600 text-white">Call Michelle</Button></a>
      </div>

      <div className="max-w-xl mx-auto mt-8 text-left bg-white/80 p-6 rounded-2xl shadow-md">
        <h3 className="font-semibold text-pink-600 mb-2">Availability</h3>
        <p className="text-gray-700">Mon–Sat, 09:00 — 20:00</p>
        <p className="mt-3 text-sm text-gray-600">For bespoke styles or men's bookings please DM.</p>
      </div>
    </section>
  )
}
