# Royal Strands Website

Next.js multi-page site for Michelle — Royal Strands (mobile hairstylist).

Deploy: push to GitHub and import the repo on Vercel (it will auto-detect Next.js).
